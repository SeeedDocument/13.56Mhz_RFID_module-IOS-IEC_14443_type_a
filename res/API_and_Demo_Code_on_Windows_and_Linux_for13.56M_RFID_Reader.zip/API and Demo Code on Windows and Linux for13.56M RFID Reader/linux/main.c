#include <./all.h>


int fd;
char *dev ="/dev/ttyS0";
int speed=9600;
struct termios oldtio; //attrib of terminal
unsigned char bufferr[1024];
unsigned char snr[6]={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};//key of card
void printdata(unsigned char * buf,int n)
{
int i;
     printf("\n");
      for(i=0;i<n;i++)
       { printf("%02X ",buf[i]);
         if((i+1)%16==0) printf("\n");
                    }
     printf("\n");

}

void init(void)
{

printf("\n************************************************************");
printf("\n*                                                          *");
printf("\n*       Demo for linux   V1.0                              *");
printf("\n*          <C>  RDM_RFID        QQ:445203853               *");
printf("\n*             Welcom to visit  http://www.datarfid.com     *");
printf("\n*              Friendship link  http://www.szanpre.com     *");
printf("\n*                      LastBuild: 20:04:12,Jan 20 2008     *");                             
printf("\n************************************************************");
printf("\n\nLoad default set... ");
printf("\n");
//printf("\n\nLoad default set... \nCurrent port: /dev/ttyS0 : 9600,n,8,1");
}

void mainmanu(void)
{
printf("\n*************************************************************");
printf("\n*                                                           *");
printf("\n*                      Index                                *");
printf("\n*   command      operation                                  *");
printf("\n*       S      :Reader command                              *");
printf("\n*       A      :ISO/IEC 14443 Type A                        *");
printf("\n*       B      :ISO/IEC 14443 Type B                        *");
printf("\n*       C      :ISO/IEC 15693                               *");
//printf("\n*       D  :Ultralight                                      *");
//printf("\n*       E  :EM4469                                          *");
//printf("\n*       F  :LCD Control                                     *");
//printf("\n*       T  :T5557                                           *");
printf("\n*       Q      :Exit                                        *");
printf("\n*                      LastBuild: 20:04:12,Jan 20 2008      *");                             
printf("\n*************************************************************");
printf("\n");
}

///////////////////////////////////////System commmand mode start/////////////

void Smanu(void)
{
printf("\n*************************************************************");
printf("\n*                                                           *");
printf("\n*           Index  for System command                       *");
printf("\n*   command      operation                                  *");
printf("\n*       L      :Set baudrate=9600                           *");
printf("\n*       H      :Set baudrate=115200                         *");
printf("\n*       Q      :Return                                      *");
printf("\n*                      LastBuild: 20:04:12,Jan 20 2008      *");                             
printf("\n*************************************************************");
printf("\n");
}

Smode(void)
{
char cmd;
int res;
int Sloop=1;
    while( Sloop>0)
                {
  Smanu();
  printf("place input command :");
  cmd=getchar();
   Sloop=1;
  if(cmd>0x20)  
 {while(getchar()!='\n') Sloop++;}
if( Sloop>1) cmd='?';
switch(cmd){
case 'L':
case 'l':
       printf("\nSet baudrate...\n");
       printf("result of Set baudrate :");
       unsigned char  num_card,Maskvalue;
       res= API_SetBaudrate(fd,0x00,0x00,bufferr);
       //0x00:9600bps;0x01:19200bps;0x02:38400bps;0x03:57600bps;0x04:115200bps;
       if(res==0||bufferr[0]==0x80)
                   {
       speed=9600;
       set_speed(fd,speed);
       printf("\nCurrent port: %s : %d,n,8,1",dev,speed);
                    }
       else
                   {
          if(res==1)
          {bufferr[1]=bufferr[0];bufferr[0]=res;printdata(bufferr,2);
                                       }
          else
          {bufferr[0]=res;printdata(bufferr,1);}
                    }
                  
       break;
case 'H':
case 'h':
       printf("\nSet baudrate...\n");
       printf("result of Set baudrate :");
       res= API_SetBaudrate(fd,0x00,0x04,bufferr);
       if(res==0||bufferr[0]==0x80)
                   {
       speed=115200;
       set_speed(fd,speed);
       printf("\nCurrent port: %s : %d,n,8,1",dev,speed);
                    }
       else
                   {
          if(res==1)
          {bufferr[1]=bufferr[0];bufferr[0]=res;printdata(bufferr,2);
                                       }
          else
          {bufferr[0]=res;printdata(bufferr,1);}
                    }
                  
       break;
case 'Q':
case 'q':
     Sloop=0;
     break;
default:
   printf("\nerror command word, place input command word again.\n");
   break;
 
        }//end switch
                 }//endloop
}
//////////////////////////////////////////System commmand mode end///////////////////////



////////////////////////////////////////////////////A card mode start/////////////

void Amanu(void)
{
printf("\n*************************************************************");
printf("\n*                                                           *");
printf("\n*           Index  for ISO/IEC 14443 Type A                 *");
printf("\n*   command      operation                                  *");
printf("\n*       S      :Request                                     *");
printf("\n*       R      :Read                                        *");
printf("\n*       W      :Write                                       *");
printf("\n*       E      :Initial electronic pure                     *");
printf("\n*       I      :Increment value                             *");
printf("\n*       D      :Decrement value                             *");
printf("\n*       Q      :Return                                      *");
printf("\n*                      LastBuild: 20:04:12,Jan 20 2008      *");                             
printf("\n*************************************************************");
printf("\n");

}

Amode(void)
{
char cmd;
int res;
int Aloop=1;
    while( Aloop>0)
                {
  Amanu();
  printf("place input command :");
  cmd=getchar();
   Aloop=1;
  if(cmd>0x20)  
 {while(getchar()!='\n') Aloop++;}
if( Aloop>1) cmd='?';
switch(cmd){
case 'S':
case 's':
       printf("\nrequest...\n");
       printf("result of request is :");
       res= API_MF_Request(fd,0x00,0x01,&bufferr[0]);
       if(res==0)
                   {
        printdata(bufferr,2);
                    }
       else
                   {
          if(res==1)
          {bufferr[1]=bufferr[0];bufferr[0]=res;printdata(bufferr,2);}
          else
          {bufferr[0]=res;printdata(bufferr,1);}
                    }
                  
       break;
case 'R':
case 'r':
    printf("\ninput number of sector(0-9) \n");
   char sector=getchar();
   if(sector>0x20)  
 {while(getchar()!='\n') Aloop++;}
 if(Aloop>1||sector>0x39||sector<0x30)
 sector=0x00;
 else
   sector-=0x30;
printf("\nread card...\n");
       memset(bufferr,0,sizeof(bufferr)/sizeof(unsigned char));
       memset(snr,0xFF,6);
       res=API_MF_Read(fd,0x00,0x01,sector*4,0x04,snr,&bufferr[0]);
       if(res==0)
                   {
        printf("\n uid is:");
        printdata(snr,4);
        printf("\nresult of read %x sector is :",sector);
        printdata(bufferr,64);
                    }
       else
                   {
          if(res==1)
          {bufferr[1]=bufferr[0];bufferr[0]=res;printdata(bufferr,2);}
          else
          {bufferr[0]=res;printdata(bufferr,1);}
                    }
       break;
case 'W':
case 'w':
      printf("\nwrite card...\n");
  printf("\ninput number of block(0-9) \n");
  sector=getchar();
   if(sector>0x20)  
 {while(getchar()!='\n') Aloop++;}
 if(Aloop>1||sector>0x40||sector<0x30)
 sector=0x00;
 else
   sector-=0x30;
      printf("result of write card is :");
      unsigned char data[16]=      {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
       memset(snr,0xFF,6);
       res=API_MF_Write(fd,0x00,0x01,sector,0x01,snr,&data[0]);
       if(res==0)
                   {
        printdata(data,4);
                    }
       else
                   {
          if(res==1)
          {bufferr[1]=bufferr[0];bufferr[0]=res;printdata(bufferr,2);}
          else
          {bufferr[0]=res;printdata(bufferr,1);}
                    }
      break;
case 'E':
case 'e':
    printf("\ninitial electronic purse...\n");
    printf("\ninput number of sector(0-9) \n");
  sector=getchar();
   if(sector>0x20)  
 {while(getchar()!='\n') Aloop++;}
 if(Aloop>1||sector>0x39||sector<0x30)
 sector=0x00;
 else
   sector-=0x30;
       
       memset(bufferr,0x00,sizeof(bufferr)/sizeof(unsigned char));
       memset(snr,0xFF,6);
       res=API_MF_InitVal(fd,0x00,0x01,sector,snr,0x64,&bufferr[0]);
       printf("result of initial ");
      if(res==0)
                   {
       printdata(bufferr,4);
                    }
       else
                   {
          if(res==1)
          {bufferr[1]=bufferr[0];bufferr[0]=res;printdata(bufferr,2);}
          else
          {bufferr[0]=res;printdata(bufferr,1);}
                    }
       break;
case 'I':
case 'i':
       printf("\nIncrement...\n");
                   printf("\ninput number of sector(0-9) \n");
   sector=getchar();
   if(sector>0x20)  
 {while(getchar()!='\n') Aloop++;}
 if(Aloop>1||sector>0x39||sector<0x30)
 sector=0x00;
 else
   sector-=0x30;
       
       memset(bufferr,0x00,sizeof(bufferr)/sizeof(unsigned char));
       memset(snr,0xFF,6);
       int rusult;
       res=API_MF_Inc(fd,0x00,0x01,sector,snr,0x01,&rusult,&bufferr[0]);
       printf("result of increment ");
      if(res==0)
                   {
       printf("\nuid:");printdata(bufferr,4);
       printf("\nvalue of rusult is %d",rusult);
                    }
       else
                   {
          if(res==1)
          {bufferr[1]=bufferr[0];bufferr[0]=res;printdata(bufferr,2);}
          else
          {bufferr[0]=res;printdata(bufferr,1);}
                    }
       break;
case 'D':
case 'd':
      printf("\nDecrement...\n");
      printf("\ninput number of sector(0-9) \n");
   sector=getchar();
   if(sector>0x20)  
 {while(getchar()!='\n') Aloop++;}
 if(Aloop>1||sector>0x39||sector<0x30)
 sector=0x00;
 else
   sector-=0x30;
       
       memset(bufferr,0x00,sizeof(bufferr)/sizeof(unsigned char));
       memset(snr,0xFF,6);
       API_MF_Dec(fd,0x00,0x01,sector,snr,0x01,&rusult,&bufferr[0]);
       printf("result of Decrement ");
      if(res==0)
                   {
       printf("\nuid:");printdata(bufferr,4);
       printf("\nvalue of rusult is %d",rusult);
                    }
       else
                   {
          if(res==1)
          {bufferr[1]=bufferr[0];bufferr[0]=res;printdata(bufferr,2);}
          else
          {bufferr[0]=res;printdata(bufferr,1);}
                    }
      break;
case 'Q':
case 'q':
     Aloop=0;
     break;
default:
   printf("\nerror command word, place input command word again.\n");
   break;
 
        }//end switch
                 }//endloop
}
//////////////////////////////////////////A card mode end///////////////////////


////////////////////////////////////////////////////B card mode start/////////////

void Bmanu(void)
{
printf("\n*************************************************************");
printf("\n*                                                           *");
printf("\n*           Index  for ISO/IEC 14443 Type B                 *");
printf("\n*   command      operation                                  *");
printf("\n*       S      :Request                                     *");
//printf("\n*       R      :Read                                        *");
//printf("\n*       W      :Write                                       *");
//printf("\n*       E      :Initial electronic pure                     *");
//printf("\n*       I      :Increment value                             *");
//printf("\n*       D      :Decrement value                             *");
printf("\n*       Q      :Return                                      *");
printf("\n*                      LastBuild: 20:04:12,Jan 20 2008      *");                             
printf("\n*************************************************************");
printf("\n");

}

Bmode(void)
{
char cmd;
int res;
int Bloop=1;
    while( Bloop>0)
                {
  Bmanu();
  printf("place input command :");
  cmd=getchar();
   Bloop=1;
  if(cmd>0x20)  
 {while(getchar()!='\n') Bloop++;}
if( Bloop>1) cmd='?';
switch(cmd){
case 'S':
case 's':
       printf("\nrequest...\n");
       printf("result of request is :");
       unsigned char  returnlen;
       res= API_Request_B(fd,0x00,&returnlen,&bufferr[0]);
       if(res==0)
                   {
        printdata(bufferr,returnlen);
        printf("\nATQB code is 0x50");
        printf("\n PUPI is :");printdata(bufferr+1,4);
        printf("Aplication Data is:");printdata(bufferr+5,4);
        printf("Protocol info is:");printdata(bufferr+9,3);
        printf("more about information ,plase reference ATQB in iso14443-3");
                    }
       else
                   {
          if(res==1)
          {bufferr[1]=bufferr[0];bufferr[0]=res;printdata(bufferr,2);
                                       }
          else
          {bufferr[0]=res;printdata(bufferr,1);}
                    }
                  
       break;
case 'Q':
case 'q':
     Bloop=0;
     break;
default:
   printf("\nerror command word, place input command word again.\n");
   break;
 
        }//end switch
                 }//endloop
}
//////////////////////////////////////////B card mode end///////////////////////

////////////////////////////////////////////////////15693 card mode start/////////////

void Cmanu(void)
{
printf("\n*************************************************************");
printf("\n*                                                           *");
printf("\n*           Index  for ISO/IEC 15693                        *");
printf("\n*   command      operation                                  *");
printf("\n*       S      :Request                                     *");
//printf("\n*       R      :Read                                        *");
//printf("\n*       W      :Write                                       *");
//printf("\n*       E      :Initial electronic pure                     *");
//printf("\n*       I      :Increment value                             *");
//printf("\n*       D      :Decrement value                             *");
printf("\n*       Q      :Return                                      *");
printf("\n*                      LastBuild: 20:04:12,Jan 20 2008      *");                             
printf("\n*************************************************************");
printf("\n");
}

Cmode(void)
{
char cmd;
int res;
int Cloop=1;
    while( Cloop>0)
                {
  Cmanu();
  printf("place input command :");
  cmd=getchar();
   Cloop=1;
  if(cmd>0x20)  
 {while(getchar()!='\n') Cloop++;}
if( Cloop>1) cmd='?';
switch(cmd){
case 'S':
case 's':
       printf("\nrequest...\n");
       printf("result of request is :");
       unsigned char  num_card,Maskvalue;
       res= API_ISO15693_Inventory(fd,0x00,0x06,0x00,0x00,&Maskvalue,&num_card,bufferr);
       if(res==0)
                   {
        printf("\n number card of request is %2x:",num_card);
       unsigned char i=0;
        for(i=0;i<num_card;i++)
               {
      printf("\n Flag of %x card is :%02X",i+1,*(bufferr+10*i));
      printf("\n DSFID of %x card is :%02X",i+1,*(bufferr+10*i+1));
      printf("\n UID of %x card is :",i+1);printdata(bufferr+10*i+2,8);}
        
                    }
       else
                   {
          if(res==1)
          {bufferr[1]=bufferr[0];bufferr[0]=res;printdata(bufferr,2);
                                       }
          else
          {bufferr[0]=res;printdata(bufferr,1);}
                    }
                  
       break;
case 'Q':
case 'q':
     Cloop=0;
     break;
default:
   printf("\nerror command word, place input command word again.\n");
   break;
 
        }//end switch
                 }//endloop
}

void closeprogram(int H_speed)
{

if(H_speed==0)
{memset(bufferr,0,sizeof(bufferr)/sizeof(unsigned char));
int rest= API_SetBaudrate(fd,0x00,0x00,bufferr);
if (rest==0||bufferr[0]==0x80) 
printf("Set baudrate is 9600\n");
}
fd=CloseComm(fd,&oldtio);
}

//////////////////////////////////////////15693 card mode end///////////////////////
/**
*@breif 	main()
*/
int main(int argc, char **argv)
{
	
	     int H_speed=1;//when close program,not set baudrate=9600
        init();
                      
        if(!(fd=OpenComm(dev,speed,&oldtio))>0)
        {fd=CloseComm(fd,&oldtio);
          
          exit(0);}

      printf("\nCurrent port: %s : %d,n,8,1",dev,speed);
       int res=-1;
       memset(bufferr,0,sizeof(bufferr)/sizeof(unsigned char));
       res= API_ControlBuzzer(fd,0x00,0x18,0x02,&bufferr[0]);
      // printf("\nres %d",res);
       memset(bufferr,0,sizeof(bufferr)/sizeof(unsigned char));
       res= API_ControlLED(fd,0x00,0x18,0x02,&bufferr[0]); 
      // printf("\nres1 %d",res1);
     //memset(bufferr,0,sizeof(bufferr)/sizeof(unsigned char));
      //memset(snr,0xFF,6);
     // res=API_MF_Read(fd,0x00,0x01,0x00,0x04,snr,&bufferr[0]);
     //              printf("\n this is read0 res: %d",res);
      //res= API_MF_Request(fd,0x00,0x01,&buffer[0]);
      //res=API_MF_Read(fd,0x00,0x01,0x00,0x04,snr,&buffer[0]);
     if(!res==0) printf("\ncommunicatioin is error with Reader ");
      if (res==0)
                { 
      H_speed=0;//when close program,set baudrate=9600
      printf("\ncommunicatioin is good with Reader ");            
      char cmd;
      int loop=1;
    while(loop>0)
                {
   mainmanu();
printf("place input command :");
  cmd=getchar();
  loop=1;
  if(cmd>0x20)  //如果输入字符与回车，知取第一个，如果只有回车（0x10)不用清缓存
 {while(getchar()!='\n')loop++;}/* Clear the input buffer */
if(loop>1) cmd='?';
//printf("print cmd %c,loop is:%d",cmd,loop);
switch(cmd){
case 'S':
case 's':
       printf("\nLoad ISO/IEC 14443 Type A Card mode...\n");
       Smode();
       break;
case 'A':
case 'a':
       printf("\nLoad ISO/IEC 14443 Type A Card mode...\n");
       Amode();
       break;
case 'B':
case 'b':
       printf("\nLoad ISO/IEC 14443 Type B Card mode...\n");
       Bmode();
       break;
case 'C':
case 'c':
      printf("\nLoad ISO/IEC 15693 Card mode...\n");
      Cmode();
      break;
case 'q':
case 'Q':
     //printf("\nQ");
     loop=0;
     break;
default:
   printf("\nerror command word, place input command word again.\n");
   break;
 
        }//end switch
                 }//endloop

               } //end if
     closeprogram(H_speed);
      
         
    //  close(fd);
    //exit(0);
}
