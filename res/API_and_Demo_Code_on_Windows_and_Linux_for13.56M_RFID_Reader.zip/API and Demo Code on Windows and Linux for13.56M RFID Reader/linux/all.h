#include     <stdio.h>      /*标准输入输出定义*/
#include     <stdlib.h>     /*标准函数库定义*/
#include     <unistd.h>     /*Unix标准函数定义*/
#include     <sys/types.h>  /**/
#include     <sys/stat.h>   /**/
#include     <fcntl.h>      /*文件控制定义*/
#include     <termios.h>    /*PPSIX终端控制定义*/
#include     <errno.h>      /*错误号定义*/
#include     <fcntl.h>
#include     <string.h>
#define HANDLE int

//计算机设置函数
void set_speed(int fd, int speed);
int set_Parity(int fd,int databits,int stopbits,int parity);
int OpenComm(char * devname,int baudrate,struct termios * oldtio);
int CloseComm(int fd,struct termios * oldtio);
//////////////////////////////////////////////////////////////////////////////
//读卡器本身操作函数
int API_SetDeviceAddress(HANDLE commHandle, int DeviceAddress,unsigned char newAddress, unsigned char *buffer);
int API_SetBaudrate(HANDLE commHandle, int DeviceAddress,unsigned char newBaud, unsigned char *buffer);
int API_SetSerNum(HANDLE commHandle, int DeviceAddress,unsigned char *newValue, unsigned char *buffer);
int API_GetSerNum(HANDLE commHandle, int DeviceAddress, unsigned char *buffer);
int API_WriteUserInfo(HANDLE commHandle, int DeviceAddress,int num_blk,int num_length,char *user_info);
int API_ReadUserInfo(HANDLE commHandle, int DeviceAddress,int num_blk,int num_length,char *user_info);
int API_GetVersionNum(HANDLE commHandle, int DeviceAddress, char *VersionNum);
int API_ControlLED(HANDLE commHandle, int DeviceAddress,unsigned char freq, unsigned char duration, unsigned char *buffer);
int API_ControlBuzzer(int commHandle, int DeviceAddress,unsigned char freq, unsigned char duration, unsigned char *buffer);
int API_SetCardType(HANDLE commHandle, int DeviceAddress,unsigned char cardtype, unsigned char *buffer);
//////////////////////////////////////////////////////////////////////////////
////ISO14443 TYPE A
int   API_MF_Request(HANDLE commHandle, int DeviceAddress, unsigned char inf_mode, unsigned char *Buffer);
int   API_MF_Anticoll(HANDLE commHandle, int DeviceAddress,unsigned char *flag,unsigned char *uid);
int   API_MF_Select(HANDLE commHandle, int DeviceAddress,unsigned char *uid,unsigned char *buffer);
int   API_MF_Halt(HANDLE commHandle, int DeviceAddress);
// ISO14443 Type-A Functions End
////////////////////////////////////////////////////////////////////////////////////////////////////
//Mifare Application API functions Begin
// 1.API_MF_Read()
int   API_MF_Read(HANDLE commHandle, int DeviceAddress,unsigned char mode,  unsigned char blk_add, unsigned char num_blk,unsigned char *snr, unsigned char *buffer);
int   API_MF_Write(HANDLE commHandle, int DeviceAddress,unsigned char mode, unsigned char blk_add, unsigned char num_blk,unsigned char *key, unsigned char *buffer);
int   API_MF_InitVal(HANDLE commHandle, int DeviceAddress,unsigned char mode, unsigned char sec_num,unsigned char *key, int  value, unsigned char *buffer);
int    API_MF_Dec(HANDLE commHandle, int DeviceAddress,unsigned char mode,unsigned char sec_num,unsigned char *key, int value,int *result, unsigned char *buffer);
int   API_MF_Inc(HANDLE commHandle, int DeviceAddress,unsigned char mode,unsigned char sec_num,unsigned char *key, int value,int *result, unsigned char *buffer);
int   API_MF_GET_SNR(HANDLE  commHandle,int DeviceAddress, unsigned char mode,unsigned char cmd,unsigned char *flag, unsigned char *buffer);
int   API_MF_Value(HANDLE  commHandle,int DeviceAddress, unsigned char mode,unsigned char add_blk,int value);int   API_MF_PowerOn(HANDLE  commHandle,int DeviceAddress, unsigned char mode,unsigned char cmd);
int   API_MF_TransferCMD(HANDLE   commHandle,int DeviceAddress, unsigned char mode, unsigned char cmdlength, unsigned char *cmd, unsigned char *returnlen, unsigned char *buffer);
int   API_MF_RST_Antenna(HANDLE  commHandle,int DeviceAddress,unsigned char *buffer);
int   API_MF_Copy_Block(HANDLE  commHandle,int DeviceAddress,unsigned char add_blk, unsigned char key, unsigned char *keyvalue,unsigned char *buffer);
int   API_MF_Auth(HANDLE  commHandle,int DeviceAddress,unsigned char mode, unsigned char add_blk, unsigned char *keyvalue);
//Mifare Application API functions End.
////////////////////////////////////////////////////////////////////////////////////////////////////
//ISO14443 Type-B Functions Begin
// 1.API_RequestType_B()
/*
buffer 卡片复位数据   ATQB
*/
int   API_Request_B(HANDLE commHandle,int DeviceAddress, unsigned char * returnlen,unsigned char *buffer);
// 2.API_AntiType_B()
//---------------------------------------------------------------------------
//Type_B Anticollion for the Type_B card.
//Parameter :DeviceAddress value from 1-255.
//          :status used for indicated tag in the antenna field.
//          -0 no more tag. 1 more then one tag at antenna field.
//Return    :Refer to the return message code.
//---------------------------------------------------------------------------
 int   API_Anticoll_B(HANDLE commHandle,int DeviceAddress, unsigned char *returnlen, unsigned char *buffer);
// 3.API_SelectType_B()
//---------------------------------------------------------------------------
//Select the Type_B tag.
//Parameter :DeviceAddress value from 1-255.
//          :SerialNum used for store 4 bytes serial number.
//          :SlotNum is used for Select tag and reader communication chanle. It from 0-F.
//Return    :Refer to the return message code.
//---------------------------------------------------------------------------
 int   API_Attrib_B(HANDLE  commHandle,int DeviceAddress,unsigned char *SerialNum,unsigned char *buffer);
// 4.API_RST_B()
 int   API_RESET_B(HANDLE commHandle,int DeviceAddress, unsigned char *buffer);
//5. API_ISO14443TypeBTransCmd()
/*
unsigned char *cmd,   待发送的数据
 int cmdSize,        数据长度
 unsigned char *buffer  回收的数据
*/
 int   API_TransferCMD_B(HANDLE commHandle, int DeviceAddress,unsigned char cmdSize, unsigned char *cmd, unsigned char *returnlen, unsigned char *buffer);

//ISO14443 Type-B Functions End.
//ISO14443 Functions End.
////////////////////////////////////////////////////////////////////////////////////////////////////
//ISO15693 Functions Begin
// 1.API_ISO15693_Inventory()
int   API_ISO15693_Inventory(HANDLE commHandle, int deviceAddress,unsigned char flag, unsigned char afi,unsigned char datalen,const unsigned char *pData,unsigned char *nrOfCard,unsigned char *pBuffer);

// 2.API_ISO15693_Read()
//ISO15693
/*
 flag      0x22    带uid
           0x02  不带uid
           0x42  不带uid但是要读安全位
 blk_add   要读的起始块号
 num_blk   块的数量
 *uid       UID信息
 *buffer   返回值
*/
 int   API_ISO15693_Read(HANDLE commHandle,int DeviceAddress,unsigned char flags,unsigned char blk_add,unsigned char num_blk,unsigned char *uid, unsigned char *returnlen, unsigned char *buffer);

// 3.API_ISO15693_Write()

 int   API_ISO15693_Write(HANDLE commHandle,int DeviceAddress,unsigned char flags,unsigned char blk_add,unsigned char num_blk,unsigned char *uid, unsigned char *data);
// 4.API_ISO15693_Lock()
int   API_ISO15693_Lock(HANDLE commHandle,int DeviceAddress,unsigned char flags, unsigned char num_blk,unsigned char *uid,unsigned char  *buffer);
//5.RDM_ISO15693_StayQuiet()
 int   API_ISO15693_StayQuiet(HANDLE commHandle,int DeviceAddress,unsigned char flags,unsigned char *uid,  unsigned char  *buffer );
//6.API_ISO15693_Select()

 int   API_ISO15693_Select(HANDLE commHandle,int DeviceAddress,unsigned char flags,unsigned char *uid,  unsigned char  *buffer );
//7.API_ISO15693_ResetToReady()
 int   API_ISO15693_ResetToReady(HANDLE commHandle,int DeviceAddress,unsigned char flags,unsigned char *uid,  unsigned char  *buffer );
//8. API_ISO15693_WriteAFI()
 int   API_ISO15693_WriteAFI(HANDLE commHandle,int DeviceAddress,unsigned char flags,unsigned char  afi,unsigned char *uid,  unsigned char  *buffer );
//9. API_ISO15693_LockAFI()
int   API_ISO15693_LockAFI(HANDLE commHandle,int DeviceAddress,unsigned char flags,unsigned char *uid,  unsigned char  *buffer );
//10. API_ISO15693_WriteDSFID()
 int   API_ISO15693_WriteDSFID(HANDLE commHandle,int DeviceAddress,unsigned char flags,unsigned char  DSFID,unsigned char *uid,  unsigned char  *buffer );
//11.API_ISO15693_LockDSFID()
int   API_ISO15693_LockDSFID(HANDLE commHandle,int DeviceAddress,unsigned char flags,unsigned char *uid,  unsigned char  *buffer );
//12. API_ISO15693_GetSysInfo()
int   API_ISO15693_GetSysInfo(HANDLE commHandle, int deviceAddress,unsigned char flag, unsigned char *uid, unsigned char *buffer);
//13.API_ISO15693_GetMulSecurity()
int   API_ISO15693_GetMulSecurity(HANDLE commHandle, int deviceAddress,unsigned char flag, unsigned char blkAddr, unsigned char blkNum, const unsigned char *uid, unsigned char *flags, unsigned char *returnlen, unsigned char *pBuffer);
//14.API_ISO15693_TransCmd()
int   API_ISO15693_TransCmd(HANDLE commHandle, int DeviceAddress, int cmdSize, unsigned char *cmd,  unsigned char *returnlen, unsigned char *pbuffer);
//ISO15693 Functions End.
///////////////////////////////////////////////////////////////////////////////////////////////////
//Attend API function
//Sys Clock Set API funtion
//*datetime:   date&time value  (7bytes)
//*buffer:       error code(1 byte)
 int   API_SysClockSet(HANDLE commHandle, int DeviceAddress,unsigned char *datetime, unsigned char *buffer);
//Sys Clock Get API funtion
//*datetime:   date&time value  (7bytes)
//*buffer:       error code(1 byte)
 int   API_SysClockGet(HANDLE commHandle, int DeviceAddress, unsigned char *buffer);
//Sys Display Inf funtion
//brightness:   brightness value
//row_adr:      row address(1-16)
//col_adr:       col address(1-8)
//strlen:         length of the display string
//str:             display string
//*buffer:       error code(1 byte)
 int   API_DisplayInf(HANDLE commHandle, int DeviceAddress, unsigned char brightness, unsigned char row_adr, unsigned char col_adr, unsigned char strlen, unsigned char *str, unsigned char *buffer);
//Get Key Value API funtion
//no input parameter
//*len:          len of key data,
//*buffer:      if ok, buffer[0..N]: key value
//                  if fail, buffer[0]: error code(1 byte)
 int   API_GetKeyValue(HANDLE commHandle, int DeviceAddress, unsigned char *len, unsigned char *buffer);
//Set Key OnOff API funtion
//onoff:         0x00: on  0x01: off
//*buffer:      if ok, buffer[0]: 0x80
//                  if fail, buffer[0[: error code(1 byte)
 int   API_SetKeyOnOff(HANDLE commHandle, int DeviceAddress, unsigned char onoff, unsigned char *buffer);
//Get History Information API funtion
//*unreadcount: the count of unread record. 
//*len:              len of record.
//*type:            the type of record 
//*buffer:      if ok, buffer[0..N]: record data
//                  if fail, buffer[0]: error code(1 byte)
 int   API_GetHistoryInfo(HANDLE commHandle, int DeviceAddress, unsigned short *unreadcount, unsigned char *len, unsigned char *types, unsigned char *buffer);
//Del History Infomation API funtion
//no input parameter
//*buffer:      if ok, buffer[0]: 0x80
//                  if fail, buffer[0[: error code(1 byte)
 int   API_DelHistoryInfo(HANDLE commHandle, int DeviceAddress, unsigned char *buffer);
//RD Des Code API funtion
//mode:        mode select   0x00: 加密  0x01: 解密
//keylen:       密钥长度(2 bytes)
//*key:           要加解密数据
//*datalen:     加解密后的数据长度
//*buffer:      if ok, buffer[0..N]: 加解密后的数据
//                  if fail, buffer[0]: error code(1 byte)
int   API_RDDesCode(HANDLE commHandle, int DeviceAddress, unsigned char mode, unsigned short keylen, unsigned char *key, unsigned short *datalen, unsigned char *buffer);
//RD Sam Reset API funtion
//samno:       number of sam socket(00-03)
//baudrate:    baudrate of sam card 1: 9600    2:19200   3:38400   4:76800
//*strlen:       len of return information
//*buffer:      if ok,  buffer[0..N]: return information
//                  if fail, buffer[0]: error code(1 byte)
int   API_RDSamReset(HANDLE commHandle, int DeviceAddress, unsigned char samno, unsigned char baudrate, unsigned short *strlen, unsigned char *buffer);
//RD Sam Gen Command API funtion
//nad:           nad address(00)
//pcb:           pcb byte
//cmdlen:      len of command
//*cmd:         cmd information
//*ret_nad:    return nad address.
//*ret_pcb:    return pcb byte
//*Res_cmdlen: len of Reponse cmd information
//*buffer:      if ok,  buffer[0..N]: Reponse cmd information
//                  if fail, buffer[0]: error code(1 byte)
int   API_RDSamGen(HANDLE commHandle, int DeviceAddress, unsigned char nad, unsigned char pcb, unsigned char cmdlen, unsigned char *cmd, unsigned char *ret_nad, unsigned char *ret_pcb, unsigned char *ret_cmdlen, unsigned char *buffer);
//RD Sam Off API funtion
//samno:       number of sam socket(00-03)
//*buffer:      if ok,  buffer[0]: 0x80
//                  if fail, buffer[0]: error code(1 byte)
int   API_RDSamOff(HANDLE commHandle, int DeviceAddress, unsigned char samno, unsigned char *buffer);
//RD CPU Reset API funtion
//type:           type of protocol 0x00: T=0 protocol,  0x01:  T=1 protocol.
//baudrate:    baudrate of CPU card 1: 9600    2:19200   3:38400   4:76800
//*strlen:       len of return information
//*buffer:      if ok,  buffer[0..N]: return information
//                  if fail, buffer[0]: error code(1 byte)
 int   API_RDCpuReset(HANDLE commHandle, int DeviceAddress, unsigned char types, unsigned char baudrate, unsigned char *strlen, unsigned char *buffer);
//RD CPU Gen Command API funtion
//nad:           nad address(00)
//pcb:           pcb byte
//cmdlen:      len of command
//*cmd:         cmd information
//*ret_nad:    return nad address.
//*ret_pcb:    return pcb byte
//*Res_cmdlen: len of Reponse cmd information
//*buffer:      if ok,  buffer[0..N]: Reponse cmd information
//                  if fail, buffer[0]: error code(1 byte)
 int   API_RDCpuGen(HANDLE commHandle, int DeviceAddress, unsigned char nad, unsigned char pcb, unsigned char cmdlen, unsigned char *cmd, unsigned char *ret_nad, unsigned char *ret_pcb, unsigned char *res_cmdlen, unsigned char *buffer);
//RD Rfcpu Reset API funtion
//type:           type of protocol 0x00: T=0 protocol,  0x01:  T=1 protocol.
//*strlen:       len of return information
//*buffer:      if ok,  buffer[0..N]: return information
//                  if fail, buffer[0]: error code(1 byte)
 int   API_RDRfcpuReset(HANDLE commHandle, int DeviceAddress, unsigned char types, unsigned char *strlen, unsigned char *buffer);
//RD Rfcpu Gen Command API funtion
//nad:           nad address(00)
//cid:            CID of card (1byte)
//pcb:           pcb byte
//cmdlen:      len of command
//*cmd:         cmd information
//*ret_nad:    return nad address.
//*ret_cid:     return cid of card.
//*ret_pcb:    return pcb byte
//*Res_cmdlen: len of Reponse cmd information
//*buffer:      if ok,  buffer[0..N]: Reponse cmd information
//                  if fail, buffer[0]: error code(1 byte)
int   API_RDRfcpuGen(HANDLE commHandle, int DeviceAddress, unsigned char nad, unsigned char cid, unsigned char pcb, unsigned char cmdlen, unsigned char *cmd, unsigned char *ret_nad, unsigned char *ret_cid, unsigned char *ret_pcb, unsigned char *ret_cmdlen, unsigned char *buffer);
//RD Rfcpu Halt API funtion
//no input parameter
//*buffer:      if ok,  buffer[0]: 0x80
//                  if fail, buffer[0]: error code(1 byte)
int   API_RDRfcpuHalt(HANDLE commHandle, int DeviceAddress, unsigned char *buffer);
//Attend API End.
////////////////////////////////////////////////////////////////////////////////////////////////////
/////////可设置串行接口接口读卡器函数
int   API_ReadDataR232(HANDLE commHandle,int DeviceAddress,unsigned char *buffer);
int   API_SetDataOutputR232(HANDLE commHandle,int DeviceAddress,unsigned char ControlMode,unsigned char ReadInfo,unsigned char StartAddress,unsigned char *Key,unsigned char *buffer);
///////////////////////////////////////////
int   API_SetDataOutputPS2(HANDLE commHandle,int DeviceAddress,unsigned char ControlMode,unsigned char ReadInfo,unsigned char StartAddress,unsigned char *Key,unsigned char *buffer);
//////////////////////////ultra light卡/////////////////
///读
int   API_UL_ReadPage(HANDLE commHandle, int DeviceAddress,unsigned char mode, unsigned char num_blk, unsigned char blk_add,unsigned char *buffer);
///////////////////////////////// 写/////////////////////////////////
int   API_UL_WritePage(HANDLE commHandle, int DeviceAddress,unsigned char mode,  unsigned char num_blk, unsigned char blk_add,unsigned char *buffer);
///////////////////////////////////
// 3.API_UL_Request()
int   API_UL_Request(HANDLE commHandle, int DeviceAddress, unsigned char inf_mode, unsigned char *Buffer);
//////////////////ultra light 卡 end////////////////
//////////////////T5557卡操作 bagin///////////////
///读
int   API_T5557_Read(HANDLE commHandle, int DeviceAddress,unsigned char num_blk, unsigned char * PassWords,unsigned char *buffer);
///////////////////////////////// 写/////////////////////////////////
int   API_T5557_Write(HANDLE commHandle, int DeviceAddress,unsigned char num_blk, unsigned char Lock,unsigned char * PassWords,unsigned char *buffer);
/////////////T5557 end////////////////////////////
///////////////em4469 bagin///////////////////////
///读
int   API_EM4469_Read(HANDLE commHandle, int DeviceAddress,unsigned char number,unsigned char add_blk,unsigned char *buffer);
///////////////////////////////// 写/////////////////////////////////
int   API_EM4469_Write(HANDLE commHandle, int DeviceAddress,unsigned char number,unsigned char add_blk,unsigned char * data,unsigned char *buffer);
//////////////////禁止命令///////////////////////////////////
int   API_EM4469_Disable(HANDLE commHandle, int DeviceAddress,unsigned char *buffer);
/////////////////////////////////登陆命令/////////////////////////////////
int   API_EM4469_Login(HANDLE commHandle, int DeviceAddress,unsigned char * data,unsigned char *buffer);
/////////////EM4469 end////////////////////////////
///LCD函数
// 1.API_LCDSetTime()
//设置系统的时间，日期，星期
int   API_LCDSetTime(HANDLE commHandle,int DeviceAddress,unsigned char secound,unsigned char minute,unsigned char hour,unsigned char day,unsigned char month, unsigned char week,unsigned char year,unsigned char *buffer);
/////////////////////////////////////////////////////////////////
 // 2.API_LCDSetPassivity()
//设置被动读卡
int   API_LCDSetPassivity(HANDLE commHandle,int DeviceAddress,unsigned char *buffer);
/////////////////////////////
 //3. API_LCDSetInitiative
//设置主动读卡
int   API_LCDSetInitiative(HANDLE commHandle,int DeviceAddress,unsigned char *buffer);
 //////////////////////////////////////////////////////////
 //4. API_LCDClrLCD
//清空液晶屏幕
int   API_LCDClrLCD(HANDLE commHandle,int DeviceAddress,unsigned char *buffer);
 //////////////////////////////////////////////////////////
 //5. API_LCDShowAscii
//显示字符，用ascii标示字符，最大为4*16=64个,命令限制为64-row*16/2-col/2 个
int   API_LCDShowAscii(HANDLE commHandle,int DeviceAddress,unsigned char row,unsigned char col,unsigned char Number,unsigned char * data,unsigned char *buffer);
//////////////////////////////////////////////////////////
 //6. API_LCDShowTime
//在固定位置显示时间，
int   API_LCDShowTime(HANDLE commHandle,int DeviceAddress,unsigned char row,unsigned char col,unsigned char *buffer);
 /////////////////////////////////////////////
 //7. API_LCDShowDate
//在固定位置显示日期，
int   API_LCDShowDate(HANDLE commHandle,int DeviceAddress,unsigned char row,unsigned char col,unsigned char *buffer);
//////////////////////////////////////////////
  //8. API_LCDShowWeek
//在固定位置显示星期，
   int   API_LCDShowWeek(HANDLE commHandle,int DeviceAddress,unsigned char row,unsigned char col,unsigned char *buffer);
 //////////////////////////////////////////////
  //9. API_LCDSetLCDFlag
//设置等待界面的显示信息项
int   API_LCDSetLCDFlag(HANDLE commHandle,int DeviceAddress,unsigned char flagtype,unsigned char value,unsigned char *buffer);
 //////////////////////////////////////////////
  //10. API_LCDSetTimeFlag
//设置显示日期，时间、星期在等待界面的显示位置，
int   API_LCDSetTimeFlag(HANDLE commHandle,int DeviceAddress,unsigned char flagtype,unsigned char row,unsigned char col,unsigned char *buffer);
//////////////////////////////////////////////
  //11. API_LCDSetLCDFlash
//设置LCD缓存内容，
int   API_LCDSetLCDFlash(HANDLE commHandle,int DeviceAddress,unsigned char row,unsigned char *data,unsigned char *buffer);
////12. API_SetIDDATA
//设置主动状态下的显示参数
int   API_SetIDDATA(HANDLE commHandle,int DeviceAddress,unsigned char row,unsigned char col,unsigned char value,unsigned char *buffer);
////13. API_refresh_cycle
//更新周期,即重新绘制LCD屏的时间间隔，以秒为单位。
  int   API_refresh_cycle(HANDLE commHandle,int DeviceAddress,unsigned char time,unsigned char *buffer);
////14. API_DispalySwitch
//显示开关,即在主动模式下是否在LCD上显示数据。


