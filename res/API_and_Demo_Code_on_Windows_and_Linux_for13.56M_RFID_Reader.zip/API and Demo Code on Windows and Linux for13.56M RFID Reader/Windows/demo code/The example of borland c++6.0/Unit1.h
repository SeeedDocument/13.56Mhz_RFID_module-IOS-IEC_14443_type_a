//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *gobConnect;
        TComboBox *cobPort;
        TLabel *Label1;
        TLabel *Label2;
        TComboBox *ComboBox2;
        TLabel *Label5;
        TComboBox *addr;
        TButton *opencom;
        TButton *closecom;
        TGroupBox *GroupBox2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label18;
        TEdit *Edit1;
        TButton *setaddr;
        TComboBox *ComboBox3;
        TButton *setbaud;
        TButton *Read_SN;
        TGroupBox *GroupBox8;
        TLabel *Label7;
        TLabel *Label10;
        TLabel *Label11;
        TLabel *Label12;
        TLabel *Label9;
        TLabel *Label13;
        TLabel *Label16;
        TLabel *Label15;
        TLabel *Label14;
        TLabel *Label8;
        TLabel *Label17;
        TGroupBox *GroupBox4;
        TRadioButton *reqa;
        TRadioButton *reqi;
        TGroupBox *GroupBox5;
        TRadioButton *keyb;
        TRadioButton *keya;
        TButton *Read;
        TComboBox *ComboBox4;
        TComboBox *ComboBox6;
        TComboBox *ComboBox5;
        TPanel *Panel1;
        TGroupBox *GroupBox6;
        TRadioButton *reqaa;
        TRadioButton *reqii;
        TGroupBox *GroupBox7;
        TRadioButton *keybb;
        TRadioButton *keyaa;
        TButton *Write;
        TComboBox *ComboBox9;
        TComboBox *ComboBox8;
        TComboBox *ComboBox7;
        TEdit *Edit3;
        TGroupBox *GroupBox3;
        TRichEdit *showm;
        void __fastcall opencomClick(TObject *Sender);
        void __fastcall closecomClick(TObject *Sender);
        void __fastcall initDlg(TObject *Sender);
        void __fastcall closeDlg(TObject *Sender, TCloseAction &Action);
        void __fastcall Read_SNClick(TObject *Sender);
        void __fastcall ReadClick(TObject *Sender);
        void __fastcall strtochar(String s,char * puchar);
        void __fastcall WriteClick(TObject *Sender);

private:	// User declarations
public:

        __fastcall TForm1(TComponent* Owner);
};

//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
 