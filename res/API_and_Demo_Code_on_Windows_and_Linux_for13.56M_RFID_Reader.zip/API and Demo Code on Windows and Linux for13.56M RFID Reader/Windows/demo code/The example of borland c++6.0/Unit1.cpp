//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "ALL.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
HANDLE hcomm;
HINSTANCE m_hInstMaster;
char temp[1024];


TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}


void __fastcall TForm1::initDlg(TObject *Sender)
{
 m_hInstMaster=LoadLibrary("ALL.dll");
 if(m_hInstMaster==0)
 return ;
 (FARPROC &)API_OpenComm=GetProcAddress(m_hInstMaster,"API_OpenComm");
 (FARPROC &)API_CloseComm=GetProcAddress(m_hInstMaster,"API_CloseComm");
 (FARPROC &)API_MF_Read    = GetProcAddress(m_hInstMaster,"API_MF_Read");
 (FARPROC &)API_MF_Write   = GetProcAddress(m_hInstMaster,"API_MF_Write");
 (FARPROC &)API_MF_InitVal = GetProcAddress(m_hInstMaster,"API_MF_InitVal");
 (FARPROC &)API_MF_GET_SNR = GetProcAddress(m_hInstMaster,"API_MF_GET_SNR");
 (FARPROC &)API_MF_Request = GetProcAddress(m_hInstMaster,"API_MF_Request");
 (FARPROC &)API_MF_Anticoll= GetProcAddress(m_hInstMaster,"API_MF_Anticoll");
 (FARPROC &)API_MF_Select  = GetProcAddress(m_hInstMaster,"API_MF_Select");
 (FARPROC &)API_MF_Halt    = GetProcAddress(m_hInstMaster,"API_MF_Halt");
 (FARPROC &)API_ControlBuzzer    = GetProcAddress(m_hInstMaster,"API_ControlBuzzer");
 (FARPROC &)API_GetSerNum        = GetProcAddress(m_hInstMaster,"API_GetSerNum");
 (FARPROC &)API_GetVersionNum    = GetProcAddress(m_hInstMaster,"API_GetVersionNum");
 (FARPROC &)API_SetDeviceAddress = GetProcAddress(m_hInstMaster,"API_SetDeviceAddress");
 (FARPROC &)API_SetSerNum        = GetProcAddress(m_hInstMaster,"API_SetSerNum");
 (FARPROC &)API_GetSerNum        = GetProcAddress(m_hInstMaster,"API_GetSerNum");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::closeDlg(TObject *Sender, TCloseAction &Action)
{
 FreeLibrary(m_hInstMaster);
 m_hInstMaster=0;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::opencomClick(TObject *Sender)
{

 //HINSTANCE handle;
 //FARPROC lpFarProc;
 //handle=LoadLibrary("ALL.dll");
  //lpFarProc=GetProcAddress(handle,"API_OpenComm");
  //API_OpenComm=(HANDLE(_cdecl *)(int, int))lpFarProc;
  //(FARPROC &)API_OpenComm=GetProcAddress(handle,"API_OpenComm");

   hcomm=API_OpenComm(cobPort->ItemIndex+1,9600);
   if (hcomm==0)
   {
     showm->Text=showm->Text+"open fail";
  }
  else
  {
  showm->Text=showm->Text+"open ok";
  opencom->Enabled=false;
  closecom->Enabled=true;
  Read_SN->Enabled=true;
  Read->Enabled=true;
  Write->Enabled=true;

  }
  //FreeLibrary(handle);



}
//---------------------------------------------------------------------------

void __fastcall TForm1::closecomClick(TObject *Sender)
{
  //HINSTANCE handle;
 //FARPROC lpFarProc;
  //(FARPROC &)API_CloseComm=GetProcAddress(handle,"API_CloseComm");
  int ret=API_CloseComm(hcomm);
  if (ret==0)
   {
     showm->Text=showm->Text+"\r\nclose fail";
  }
  else
  {
  showm->Text=showm->Text+"\r\nclose ok";
  opencom->Enabled=true;
  closecom->Enabled=false;
  Read_SN->Enabled=false;
  Read->Enabled=false;
  Write->Enabled=false;
  }



}
//---------------------------------------------------------------------------



void __fastcall TForm1::Read_SNClick(TObject *Sender)
{
unsigned char buff[8];
 API_GetSerNum(hcomm,0,buff);
String s,s1;
 showm->Text=showm->Text+"\r\nAddress of Reader is :"+IntToHex(buff[0],2)+"\r\nSerial Number of reader is:";

// buff[0] is reader address
 s="";
 int i,k;
 unsigned char kk;
 for(i=1;i<8;i++)
 {
  //http://blog.chinaunix.net/u2/68070/showart_691439.html
  //s1=IntToStr(buff[i]);  //������ת��ΪAnsiString�ַ���(10����),
  s1=IntToHex(buff[i],2); //������ת��Ϊʮ�������ַ���(2������Ϊת����λ��)
  s=s+s1+" ";
 }
 showm->Text=showm->Text+s;
 }
 //---------------------------------------------------------------------------
 void __fastcall TForm1::strtochar(String s,char puchar[])
{
   char * pc;
   int i=0,j=0;

   StrPCopy(temp,UpperCase(s));
   // del blank
   while(pc=StrScan(temp,0x20))
   {
     StrCopy(pc,pc+1);
   }
   if((i=StrLen(temp))%2==1)
   temp[i]=0x30;
   i=i/2;
   while(j<i)
     {
     if(temp[2*j]<0x39)
     puchar[j]=StrToInt(temp[2*j]);
     else
     puchar[j]=temp[2*j]-0x41+10;

     if(temp[2*j+1]<0x39)
     puchar[j]=puchar[j]*16+StrToInt(temp[2*j+1]);
     else
     puchar[j]=puchar[j]*16+(temp[2*j+1]-0x41)+10;
     j++;
     }
}




 //--------------------------------------------
void __fastcall TForm1::ReadClick(TObject *Sender)
{
unsigned char mode;
unsigned char add_blk,num_blk;
char buffer[6],bufferr[255];
int receive,i;
String keydata;
char * pchar ;


  if (reqi->Checked && keya->Checked)
     mode=0x00;
  if (reqa->Checked && keya->Checked)
      mode=0x01;
  if (reqi->Checked && keyb->Checked)
     mode=0x02;
  if (reqa->Checked && keyb->Checked)
      mode=0x03;

  add_blk=StrToInt((AnsiString )ComboBox5->Text);
  num_blk=StrToInt((AnsiString )ComboBox6->Text);
  keydata=ComboBox4->Text;
  strtochar(keydata,buffer);
  int ret=API_MF_Read(hcomm,0,mode,add_blk,num_blk,buffer,bufferr);
  if(ret==0)
  {
   showm->Text=showm->Text+"\r\nRead success"+"\r\nData of read is :";
   String s="",ss;
   for(unsigned char i=0;i<num_blk*16;i++)
   {
    ss=IntToHex(bufferr[i]& 0xff,2);
    s=s+ss+" ";
   }
   showm->Text=showm->Text+s;
  }
    else
  {
  showm->Text=showm->Text+"\r\nAread fail"  ;
  }


}
//---------------------------------------------------------------------------

void __fastcall TForm1::WriteClick(TObject *Sender)
{
unsigned char mode;
unsigned char add_blk,num_blk;
char buffer[6],bufferr[255];
int receive,i;
String keydata,carddata;
char * pchar ;


  if (reqii->Checked && keyaa->Checked)
     mode=0x00;
  if (reqaa->Checked && keyaa->Checked)
      mode=0x01;
  if (reqii->Checked && keybb->Checked)
     mode=0x02;
  if (reqaa->Checked && keybb->Checked)
      mode=0x03;

  add_blk=StrToInt((AnsiString )ComboBox7->Text);
  num_blk=StrToInt((AnsiString )ComboBox8->Text);
  keydata=ComboBox9->Text;
  strtochar(keydata,buffer);
  carddata=Edit3->Text;
  strtochar(carddata,bufferr);

  int ret=API_MF_Write(hcomm,0,mode,add_blk,num_blk,buffer,bufferr);
  if(ret==0)
  {
   showm->Text=showm->Text+"\r\nWrite success"+"\r\nSN of card is :";
   String s="",ss;
   for(unsigned char i=0;i<4;i++)
   {
    ss=IntToHex(bufferr[i]& 0xff,2);
    s=s+ss+" ";
   }
   showm->Text=showm->Text+s;
  }
    else
  {
  showm->Text=showm->Text+"\r\nAread fail"  ;
  }
}
//---------------------------------------------------------------------------

