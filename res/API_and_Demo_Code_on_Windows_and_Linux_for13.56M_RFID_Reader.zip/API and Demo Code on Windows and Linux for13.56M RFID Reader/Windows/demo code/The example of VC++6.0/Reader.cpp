
#include "stdafx.h"
#include "Reader.h"
#include "ALL.h"

#define BTL_9600 9600
#define BTL_57600 57600


static char *GetCommStr(int com)
{
	switch(com)
	{
		case 1: return "COM1";
		case 2: return "COM2";
		case 3: return "COM3";
		case 4: return "COM4";
		case 5: return "COM5";
		case 6: return "COM6";
		case 7: return "COM7";
		case 8: return "COM8";
	}
	return "COM";
		
}
CReader::CReader()
{
	DeviceAddress = 0;
	m_hInstMaster = NULL;
	LoadDll();

}
CReader::~CReader()
{
	
	if(hComm)
		CloseComm();
	CloseDll();
}
int CReader::LoadDll()
{
	printf("sd");
	char buf[1024];
	GetCurrentDirectory(1024,buf);
	CString str;
	str.Format("%s",buf);
	m_hInstMaster = LoadLibrary(".\\ALL.DLL");	// Loaded 'E:\EXAMEX4\RMD\mi.dll', no matching symbolic information found.
	if(!m_hInstMaster)
	{
		DWORD er = GetLastError();
		MessageBox(NULL,"load(all.dll)fail!","alarm",MB_OK | MB_ICONERROR);
	    exit(0);
	}

	(FARPROC &)API_OpenComm   = GetProcAddress(m_hInstMaster,_T("API_OpenComm"));
	(FARPROC &)API_CloseComm  = GetProcAddress(m_hInstMaster,_T("API_CloseComm"));
	(FARPROC &)API_MF_Read    = GetProcAddress(m_hInstMaster,_T("API_MF_Read"));
	(FARPROC &)API_MF_Write   = GetProcAddress(m_hInstMaster,_T("API_MF_Write"));
	(FARPROC &)API_MF_InitVal = GetProcAddress(m_hInstMaster,_T("API_MF_InitVal"));
	//(FARPROC &)API_PCDDec   = GetProcAddress(m_hInstMaster,_T("API_PCDDec"));
	//(FARPROC &)API_PCDInc   = GetProcAddress(m_hInstMaster,_T("API_PCDInc"));
	(FARPROC &)API_MF_GET_SNR = GetProcAddress(m_hInstMaster,_T("API_MF_GET_SNR"));
	(FARPROC &)API_MF_Request = GetProcAddress(m_hInstMaster,_T("API_MF_Request"));
	(FARPROC &)API_MF_Anticoll= GetProcAddress(m_hInstMaster,_T("API_MF_Anticoll"));
	(FARPROC &)API_MF_Select  = GetProcAddress(m_hInstMaster,_T("API_MF_Select"));
	(FARPROC &)API_MF_Halt    = GetProcAddress(m_hInstMaster,_T("API_MF_Halt"));
	//(FARPROC &)MF_Restore   = GetProcAddress(m_hInstMaster,_T("MF_Restore"));
	(FARPROC &)API_ControlBuzzer      = GetProcAddress(m_hInstMaster,_T("API_ControlBuzzer"));
	(FARPROC &)API_GetSerNum          = GetProcAddress(m_hInstMaster,_T("API_GetSerNum"));
	(FARPROC &)API_GetVersionNum      = GetProcAddress(m_hInstMaster,_T("API_GetVersionNum"));
	(FARPROC &)API_SetDeviceAddress   = GetProcAddress(m_hInstMaster,_T("API_SetDeviceAddress"));
	(FARPROC &)API_SetSerNum          = GetProcAddress(m_hInstMaster,_T("API_SetSerNum"));
	(FARPROC &)API_GetSerNum          = GetProcAddress(m_hInstMaster,_T("API_GetSerNum"));
	if( API_OpenComm      == NULL || 
		API_CloseComm     == NULL ||
		API_MF_Read       == NULL ||
		API_MF_Write      == NULL ||
		API_MF_InitVal    == NULL ||
		//API_PCDDec        == NULL ||
		//API_PCDInc        == NULL ||
		API_MF_GET_SNR        == NULL ||
		API_MF_Request        == NULL ||
		API_MF_Anticoll       == NULL ||
		API_MF_Select        == NULL ||
	    API_MF_Halt       == NULL ||
		//MF_Restore        == NULL ||
		API_GetSerNum           == NULL ||
		API_GetVersionNum      == NULL ||
		API_SetDeviceAddress  == NULL ||
		API_SetSerNum         == NULL ||
		API_GetSerNum         == NULL ||
		API_ControlBuzzer == NULL  )
	{
		MessageBox(NULL,"load(all.dll)fail!","alarm",MB_OK | MB_ICONERROR);
		exit(0);
		return 0;
	}
  /* */
    return 1;
}
int CReader::CloseDll()
{
	if(m_hInstMaster)
	{
		FreeLibrary(m_hInstMaster);
		API_OpenComm      = NULL ; 
		API_CloseComm     = NULL ;
    	API_MF_Read       = NULL ;
		API_MF_Write      = NULL ;
		API_MF_InitVal    = NULL ;
		//API_PCDDec        = NULL ;
		//API_PCDInc        = NULL ;
		API_MF_GET_SNR         = NULL ;
		API_MF_Request        = NULL ;
		API_MF_Anticoll       = NULL ;
		API_MF_Select         = NULL ;
		//MF_Restore        = NULL ;
		API_GetSerNum           = NULL ;
		API_ControlBuzzer = NULL ;
		API_MF_Halt           = NULL ;
		return 1;
	}
	return 0;
}
HANDLE CReader::GetHComm()
{ return hComm;}
int CReader::OpenComm(int com,int bp)
{
	if(hComm)
		return 1;  
	if(com<1 || com >8)
		return 3;
	//hComm = API_OpenComm(GetCommStr(com),bp);
	hComm = API_OpenComm(com,bp);
	if(!hComm)
		return 2;  
	Buzzer(10,1);
	mCommPort = com;
	mBandRate = bp;
	return 0;
}
int CReader::OpenComm(int bp)
{
	if(hComm)
		return 1;  
	if(mCommPort<1 || mCommPort >8)
		return 3;
	hComm = API_OpenComm(mCommPort,bp);
	if(!hComm)
		return 2;  
	Buzzer(10,1);
	return 0;
}
int CReader::CloseComm()
{
	if(hComm)
		int i = API_CloseComm(hComm);	
	hComm = NULL;
	return 1;
}
int CReader::SetDeviceAddress(int da)
{
	int last = DeviceAddress;
	DeviceAddress = da;
	return last;
}
CString CReader::GetCardStrSerial()
{
	CString strre;
	BYTE buf[128];
	Buzzer(1,1);
	if(GetCardByteSerial(buf) == 0)
	{
		strre.Format("%02x%02x%02x%02x",buf[0],buf[1],buf[2],buf[3]);
		return strre;
	}
	return "";
}
int CReader::GetCardByteSerial(BYTE  *pSerial)
{
	BYTE buf[128];
	BYTE snr[16];
	int result = 0;
	memset(buf,0,128);
	memset(snr,0,16);
	if (hComm == INVALID_HANDLE_VALUE)
		return 1 ;
	if((result = API_MF_GET_SNR(hComm, DeviceAddress, 0X01, 0x00,
		snr,buf)) != 0x00)
		return 2;
	memcpy(pSerial,buf,4);
	Buzzer(5,1);
	return 0;
}
//64��block
int CReader::ReadBLOCK(int add,BYTE *pData)
{
	if(!hComm)
		return 1; 
	if(add<0 || add>64)
		return 10;
	BYTE buf[128];
	int result = 0;
	memset(buf,0,128);
    if((result = GetCardByteSerial(buf)) != 0x00)
		return result;
	BYTE dataBuf[1024];
    memset(buf,0xff,6);
	memset(dataBuf,0,128);
	if((result = API_MF_Read(hComm,DeviceAddress,0x00,add,1,buf,dataBuf)) != 0x00)
		return 6;
	memcpy(pData,dataBuf,16);
	Buzzer(2,1);
	return 0;

}
int CReader::ReadBLOCKWithCode(int add,BYTE *pData,BYTE *pCode)
{
	if(!hComm)
		return 1; 
	if(add<0 || add>64)
		return 10;
	if(add >=4 && add<= 7)
		add = add;
	BYTE buf[128];
	int result = 0;
	memset(buf,0,128);
    if((result = GetCardByteSerial(buf)) != 0x00)
		return result;
	BYTE dataBuf[128];
    memcpy(buf,pCode,6);
	memset(dataBuf,0,128);
	if((result = API_MF_Read(hComm,DeviceAddress,0x00,add,1,buf,dataBuf)) != 0x00)
		return 6;
	memcpy(pData,dataBuf,16);
	return 0;

}
int CReader::ReadBlock(int add,int mod,BYTE *pData,BYTE *pCode,int len)
{
	if(!hComm)
		return 1; 
	if(add<0 || add>64)
		return 10;
	if(add >=4 && add<= 7)
		add = add;
	if(mod <0 || mod>1)
		return 101;
	if(len > 4)
		len = 4;
	if(len < 1)
		len = 1;
	BYTE buf[128];
	int result = 0;
	memset(buf,0,128);
    if((result = GetCardByteSerial(buf)) != 0x00)
		return result;
	BYTE dataBuf[128];
    memcpy(buf,pCode,6);
	memset(dataBuf,0,128);
	if((result = API_MF_Read(hComm,DeviceAddress,mod,add,len,buf,dataBuf)) != 0x00)
		return 6;
	memcpy(pData,dataBuf,16*len);
	return 0;

}
//һ��256��DWORD����ַ���Ҿ��Ա�ű���
int CReader::ReadWORD(int add,DWORD &revData)
{
	if(!hComm)
		return 1; 
	BYTE bAdd = add/4;
	if(bAdd<0 || bAdd>256)
		return 10;
	BYTE buf[128];
	int result = 0;
	memset(buf,0,128);
    if((result = GetCardByteSerial(buf)) != 0x00)
		return result;
	BYTE dataBuf[1024];
	memset(buf,0xff,6);
	memset(dataBuf,0,128);
	if((result = API_MF_Read(hComm,DeviceAddress,0x00,bAdd,2,buf,dataBuf)) != 0x00)
		return 6;
	else
	{
		revData = 0;
		bAdd = (add%4)*4;
		revData |= dataBuf[bAdd++];		revData = revData<<8;
		revData |= dataBuf[bAdd++];		revData = revData<<8;
		revData |= dataBuf[bAdd++];		revData = revData<<8;
		revData |= dataBuf[bAdd];	
		return 0;
	}
}

//һ��1024��BTYE����ַ���Ҿ��Ա�ű���
int CReader::ReadBYTE(int add,BYTE  &revData)
{
	if(!hComm)
		return 1; 
	BYTE bAdd = add/16 + 1;
	if(bAdd<0 || bAdd>15)
		return 10;
	BYTE buf[128];
	int result = 0;
	memset(buf,0,128);
    if((result = GetCardByteSerial(buf)) != 0x00)
		return result;
	if((result = API_MF_Select(hComm, DeviceAddress, buf,buf)) != 0x00)
		return 5 ;
	BYTE dataBuf[1028];
	memset(buf,0xff,6);
	memset(dataBuf,0,128);
	if((result = API_MF_Read(hComm,DeviceAddress,0x00,bAdd,1,buf,dataBuf)) != 0x00)
		return 6;
	else
	{
		bAdd = add%16;
		revData = dataBuf[bAdd++];
		return 0;
	}
}
int CReader::WriteBLOCK(BYTE add,BYTE *pData)
{
	if(!hComm)
		return 1; 
	if(add<0 || add>64)
		return 10;
	if(add%4 == 3)
		return 11;
	BYTE buf[128];
	int result = 0;
	memset(buf,0,128);
    if((result = GetCardByteSerial(buf)) != 0x00)
		return result;
	memset(buf,0xff,16);
	if((result = API_MF_Write(hComm,DeviceAddress,0,add,1,buf,pData)) != 0x00)
		return 6;
	Buzzer(5,1);
	return 0;
}
int CReader::WriteBlock(BYTE add,int mod,BYTE *pCode,int len,BYTE *pData)
{
	if(!hComm)
		return 1; 
	if(add<0 || add>64)
		return 10;
	if(add%4 == 3)
		return 11;
	BYTE buf[128];
	int result = 0;
	memset(buf,0,128);
    if((result = GetCardByteSerial(buf)) != 0x00)
		return result;
	memset(buf,0xff,16);
	if((result = API_MF_Write(hComm,DeviceAddress,mod,add,len,pCode,pData)) != 0x00)
		return 6;
	Buzzer(5,1);
	return 0;
}
int CReader::WriteWORD(int add,DWORD wData)
{
	return 2;
}
int CReader::WriteBYTE(int add,BYTE  wData)
{return 0;}
void CReader::Buzzer(int time,int count)
{
	if(!hComm)
		return ;  
	BYTE buf[128];
	int re = API_ControlBuzzer(hComm,DeviceAddress,time,count,buf);

}
CString CReader::GetSnr()
{
	BYTE buf[128];
	memset(buf,1,128);
	int re = 0;
	if((re = API_GetSerNum(hComm,DeviceAddress,buf)) == 0)
	{
		CString str;
		str.Format("%02x %02x %02x %02x %02x %02x %02x %02x",
				buf[1],buf[2],buf[3],
				buf[4],buf[5],buf[6],buf[7],buf[8]);
		return str;
	}
	else
		return "";
}
int CReader::SetSnr(BYTE  *pSnr)
{
	if(!pSnr) return 1;
	BYTE buf[128];
	memset(buf,1,128);
	int re = API_SetSerNum(hComm,DeviceAddress,pSnr,buf);
	return re;
}












