//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by friend1.rc
//
#define IDD_MORE_INFORMATION            1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FRIEND1_DIALOG              102
#define IDD_MORE_INFORMATION2           104
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     131
#define IDC_EDIT2                       1001
#define IDC_TAB1                        1002
#define IDC_COMBOBOXEX1                 1009
#define IDC_COMBOBOXEX2                 1010
#define IDC_COMBOBOXEX3                 1011
#define IDC_BUTTON1                     1012
#define IDC_BUTTON2                     1013
#define IDC_RICHEDIT1                   1014
#define IDC_BUTTON3                     1014
#define IDC_EDIT3                       1016
#define IDC_COMBO1                      1016
#define IDC_BUTTON4                     1017
#define IDC_COMBO2                      1017
#define IDC_COMBO3                      1018
#define IDC_COMBO4                      1019
#define IDC_SERIAL                      1020
#define IDC_COMBO5                      1023
#define IDC_BUTTON5                     1024
#define IDC_EDIT1                       1025
#define IDC_COMBO6                      1026
#define IDC_S                           1026
#define IDC_COMBO7                      1027
#define IDC_COMBO8                      1028
#define IDC_COMBO9                      1029
#define IDC_COMBO10                     1030
#define IDC_COMBO11                     1031
#define IDC_COMBO12                     1032
#define IDC_COMBO13                     1033
#define IDC_COMBO14                     1034
#define IDC_BUTTON6                     1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
